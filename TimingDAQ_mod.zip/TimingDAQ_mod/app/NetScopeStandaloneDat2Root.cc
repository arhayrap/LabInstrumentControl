// C++ includes
#include <string>
#include <assert.h>

// ROOT includes
#include <TROOT.h>

//LOCAL INCLUDES
#include "NetScopeStandaloneAnalyzer.hh"

using namespace std;

int main(int argc, char **argv) {
  gROOT->SetBatch();

  int num_channels = NetScope_CHANNELS;
  int num_samples = NetScope_SAMPLES;

  for(int i = 1; i < argc; i++) {
    string arg = argv[i];

  if(arg.find("--num_channels=") == 0) {
    num_channels = stoi(arg.substr(string("--num_channels=").length()));
  }

  if(arg.find("--num_samples=") == 0) {
    num_samples = stoi(arg.substr(string("--num_samples=").length()));
  }  

}

  NetScopeStandaloneAnalyzer* analyzer = new NetScopeStandaloneAnalyzer(num_channels, num_samples);
  analyzer->GetCommandLineArgs(argc, argv);
  analyzer->RunEventsLoop();

  return 0;
}
