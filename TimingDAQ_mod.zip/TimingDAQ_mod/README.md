### Installation
You will need ROOT, g++, etc.<br>
1. Download the zip and unarchive it, or clone the directory.
2. `cd` into your `TimingDAQ_mod` directory and run:
~~~bash
make -j$(nproc)
~~~

### What's changed?
Only added `--num_channels` and `--num_samples` in the command line arguments so there is no need to recompile the analyzer for every *sample per segment* and *number of channels*. The rest of the code remains untouched. Also, left only the `NetScopeStandaloneDat2Root` preprocessor instance.

### Example usage
~~~bash
./NetScopeStandaloneDat2Root \
--input_file="/home/plexar/conv_test.root" \
--verbose=true \
--save_meas=true \
--num_channels=2 \
--num_samples=5120 \
--output_file="/home/plexar/prep_test.root" \
--config="/home/plexar/myconfig.config"
~~~

### More documentation
See [TimingDAQ](https://github.com/CMS-MTD/TimingDAQ) for more detailed documentation.

***Jul 2026, Samvel Aghavelyan***